#pragma once

#include "AAlloc.h"
#include "BinAlgo.h"
#include "SIMD.h"

#include <algorithm>
#include <limits>


#include "Algo-Direct2.h"
